package Atividade01;

public class Conta {

    private String agencia;
    private String cc;
    private Dinheiro saldo;
    private Dinheiro limite;
    private Cliente titular;

    public Conta(int numero, String nome, String sobrenome, String cpf, double saldo) {
        this.titular = new Cliente(nome, sobrenome, cpf);
        
        this.saldo = saldo;

    }

    

    public double getSaldo() {
        return this.saldo;
    }

    void visualizarSaldo() {
        System.out.println("Saldo = " + this.saldo);
    }

    boolean depositar(double valor) {
        if (valor > 0) {
            this.saldo.valor = this.saldo.valor + valor;
            return true;
        } else {
            return false;
        }
    }

    public void visualizarConta() {

        Cliente a = new Cliente("a", "b", "c");
        String b = a.getCpf();
        String c = a.getNome();
        String d = a.getSobrenome();
        System.out.println("Nome do titular = " + c);
        System.out.println("sobrenome = " + d);
        System.out.println("cpf = " + b);
        System.out.println("saldo =" + this.saldo);
    }

    boolean sacar(double valor) {
        if (valor > this.saldo || valor <= 0) {

            return false;

        } else {
            this.saldo = this.saldo - valor;
            return true;
        }
    }

    boolean transferirPara(Conta x, double valor) {
        if (this.sacar(valor)) {
            x.depositar(valor);
            System.out.println("Transferencia realizada");
            return true;
        } else {
            System.out.println("Transferencia Não realizada");
        }
        return false;

    }

}
