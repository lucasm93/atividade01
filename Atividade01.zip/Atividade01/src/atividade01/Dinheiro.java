package atividade01;

public class Dinheiro {

    private double valor;
    private String moeda;
    private double taxaEuroDolar;
    private double taxaRealDolar;

    public Dinheiro(double valor, String moeda, double taxaEuroDolar, double taxaRealDolar) {
        this.valor = valor;
        this.moeda = moeda;
        this.taxaEuroDolar = taxaEuroDolar;
        this.taxaRealDolar = taxaRealDolar;
    }

    public double realParaDolar(double valor) {
        this.valor = this.valor / taxaRealDolar;
        return this.valor;
    }

    public double dolarParaReal(double valor) {
        this.valor = this.valor * taxaRealDolar;
        return this.valor;
    }

    public double euroParaDolar(double valor) {
        this.valor = this.valor / taxaEuroDolar;
        return this.valor;
    }

    public double dolarParaEuro(double valor) {
        this.valor = this.valor * taxaEuroDolar;
        return this.valor;
    }

    public double valorEmReal(double valor) {

        if (this.moeda.equals("dolar")) {

            dolarParaReal(this.valor);
        }

        if (this.moeda.equals("euro")) {

            this.valor = euroParaDolar(this.valor);
            this.valor = dolarParaReal(this.valor);

        }
        return this.valor;

    }

    public double valorEmDolar(double valor) {

        if (this.moeda.equals("real")) {

            realParaDolar(this.valor);
        }

        if (this.moeda.equals("euro")) {

            this.valor = euroParaDolar(this.valor);

        }
        return this.valor;

    }

    public double valorEmEuro(double valor) {

        if (this.moeda.equals("real")) {

            this.valor = realParaDolar(this.valor);
            this.valor = dolarParaEuro(this.valor);

        }

        if (this.moeda.equals("dolar")) {

            this.valor = dolarParaEuro(this.valor);

        }
        return this.valor;

    }

    public double getTaxaRealDolar() {
        return this.taxaRealDolar;
    }

    public double getTaxaEuroDolar() {
        return this.taxaEuroDolar;
    }

    public String getMoeda() {
        return this.moeda;
    }

    public void setMoeda(String W) {

        if (W.equals("real")) {

            if (this.moeda.equals("dolar")) {
                this.valor = realParaDolar(this.valor);
            }

            if (this.moeda.equals("euro")) {
                this.valor = realParaDolar(this.valor);
                this.valor = dolarParaEuro(this.valor);
            }
        }

        if (W.equals("dolar")) {

            if (this.moeda.equals("real")) {
                this.valor = dolarParaReal(this.valor);
            }

            if (this.moeda.equals("euro")) {
                this.valor = dolarParaEuro(this.valor);
            }
        }

        if (W.equals("euro")) {

            if (this.moeda.equals("dolar")) {
                this.valor = euroParaDolar(this.valor);
            }

            if (this.moeda.equals("real")) {
                this.valor = euroParaDolar(this.valor);
                this.valor = dolarParaReal(this.valor);
            }
        }

    }

    public void alterarTaxaRealDolar(double A) {
        this.taxaRealDolar = A;
    }

    public void alterarTaxaEuroDolar(double A) {
        this.taxaEuroDolar = A;
    }

}
