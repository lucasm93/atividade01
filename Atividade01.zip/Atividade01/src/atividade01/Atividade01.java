/*
 Andre chioratto 13.02642-9
 */
package atividade01;

/**
 *
 * @author Professor
 */
public class Atividade01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
